Description of the package:

This package is for Heart Rate Variability Analysis

Installation / usage :
> $ pip install hrvanalysis


